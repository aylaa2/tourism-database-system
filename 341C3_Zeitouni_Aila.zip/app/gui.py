import tkinter as tk
from tkinter import ttk, messagebox
import oracledb

class TurismSiriaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistem Turism Siria - REAL DB")
        self.root.geometry("1000x700")
        self.connection = None
        self.create_layout()

    def create_layout(self):
        # Meniu
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Fisier", menu=file_menu)
        file_menu.add_command(label="Conectare BD", command=self.connect_db)
        
        # Layout principal
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Stanga: Butoane
        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        
        ttk.Label(left_frame, text="Rapoarte:", font=('Arial', 12, 'bold')).pack(pady=10)
        
        reports = [
            ("Top Locatii Rating", "sp_top_locatii_rating"),
            ("Statistici Tururi", "sp_statistici_tururi_regiune"),
            ("Turisti Activi", "sp_analiza_turisti_activi"),
            ("Performanta Ghizi", "sp_performanta_ghizi"),
            ("Situri UNESCO", "sp_popularitate_unesco")
        ]
        
        for name, proc in reports:
            btn = ttk.Button(left_frame, text=name, command=lambda p=proc: self.run_report(p))
            btn.pack(fill=tk.X, pady=5)

        # Dreapta: Tabel
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        self.tree = ttk.Treeview(right_frame, show='headings')
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        self.status_lbl = ttk.Label(self.root, text="Neconectat", foreground="red")
        self.status_lbl.pack(side=tk.BOTTOM, fill=tk.X)

    def connect_db(self):
        # Conectare Hardcodata pentru rapiditate (poti schimba parola aici)
        try:
            self.connection = oracledb.connect(
                user="system",
                password="student",
                dsn="localhost:1521/XEPDB1"
            )
            self.status_lbl.config(text="CONECTAT LA ORACLE", foreground="green")
            messagebox.showinfo("Succes", "Conectat la baza de date!")
        except Exception as e:
            messagebox.showerror("Eroare", f"Nu m-am putut conecta:\n{e}")

    def run_report(self, proc_name):
        if not self.connection:
            messagebox.showwarning("Atentie", "Nu sunteti conectat la baza de date!\nMergi la Fisier -> Conectare BD.")
            return

        # Sterge datele vechi
        for row in self.tree.get_children():
            self.tree.delete(row)

        try:
            cursor = self.connection.cursor()
            ref_cursor = self.connection.cursor()
            
            # Apel procedura
            cursor.callproc(proc_name, [ref_cursor])
            
            # Configurare coloane
            columns = [col[0] for col in ref_cursor.description]
            self.tree["columns"] = columns
            for col in columns:
                self.tree.heading(col, text=col)
                self.tree.column(col, width=120)

            # Inserare date
            rows = ref_cursor.fetchall()
            for row in rows:
                self.tree.insert("", tk.END, values=row)
                
            self.status_lbl.config(text=f"Raport {proc_name}: {len(rows)} inregistrari gasite.")
            
        except Exception as e:
            messagebox.showerror("Eroare SQL", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = TurismSiriaApp(root)
    root.mainloop()